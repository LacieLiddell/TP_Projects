def quack():
    print "quack"
