import sys
# sys.path.append("C:\\Users\\lacie\\PycharmProjects\\test_lib")
# from api.test_framework.test_framework import *

#путь придётся поменять
sys.path.insert(0, "C:\\Users\\lacie\\PycharmProjects\\test_lib")
from dir_test.duck import quack
# from dir_test.duck import quack
# from dir_test.duck import *


def connection():
    quack()
    # testFramework = TestFramework()
    # testFramework.connTkpa()


if __name__() == "__main__":
    connection()
